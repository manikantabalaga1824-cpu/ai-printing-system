# Licensing and provenance

- The SVG compositions in this package were generated specifically for this AI Print OS collection.
- The templates do not intentionally include third-party template files or third-party raster images.
- Fonts are referenced by common system font families (Arial/Helvetica/sans-serif); no font files are bundled.
- If you add external artwork, icons, images, fonts, or native CDR/PSD/AI files later, record the original URL, creator, exact licence, attribution requirements, modification status, and whether redistribution inside a commercial editor is allowed.
- This notice is not legal advice. Review the applicable law and licences before commercial distribution.
