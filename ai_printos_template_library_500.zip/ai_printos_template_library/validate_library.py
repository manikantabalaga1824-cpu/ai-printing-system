import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parent
manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
assert len(manifest["templates"]) == 500, f"Expected 500 templates, found {len(manifest['templates'])}"
ids = [t["id"] for t in manifest["templates"]]
assert len(ids) == len(set(ids)), "Duplicate template IDs found"
missing = []
bad_svg = []
for item in manifest["templates"]:
    rel = item["assets"]["design"].lstrip("/")
    path = ROOT / rel
    if not path.exists():
        missing.append(str(path))
        continue
    try:
        ET.parse(path)
    except Exception as e:
        bad_svg.append((str(path), str(e)))
assert not missing, f"Missing files: {missing[:10]}"
assert not bad_svg, f"Invalid SVG: {bad_svg[:3]}"
print(f"Validated {len(ids)} template entries and SVG files.")
for category in manifest["categories"]:
    actual = sum(1 for t in manifest["templates"] if t["category"] == category["id"])
    assert actual == category["count"], f"{category['id']}: expected {category['count']}, found {actual}"
    print(f"{category['name']}: {actual}")
