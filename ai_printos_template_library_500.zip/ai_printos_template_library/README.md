# AI Print OS — 500 Template Starter Library

This package contains 500 original, generated SVG starter layouts across eight print categories. Each template has an SVG source and JSON metadata. Designs use vector shapes and editable text, and are intended as a foundation for the AI Print OS browser editor.

## Category counts
- Visiting cards: 75
- Wedding invitations: 75
- Brochures: 50
- Flyers: 75
- Posters: 75
- Banners: 50
- Stickers and labels: 50
- Catalogs: 50

## Contents
- `templates/<category>/<id>.svg` — editable vector source
- `templates/<category>/<id>.json` — metadata and editable text placeholders
- `manifest.json` — central template index
- `LICENSES.md` — asset/licensing notes
- `validate_library.py` — checks manifest counts and SVG files

## Import notes
1. Copy the `templates/` folder and `manifest.json` into your app's public assets directory.
2. Adapt your template loader to read `manifest.json`.
3. Load the SVG source into the existing editor. For full object-level editing, parse SVG elements into your editor's object model rather than flattening it to an image.
4. Replace placeholder text and shapes as needed.
5. Test PDF/PNG export and physical dimensions in your actual print pipeline.

## Important print note
These are vector starter layouts, not certified press-ready artwork. Validate dimensions, bleed, safe areas, fonts, linked images, color handling, and export quality for each printer before production. CMYK and PDF/X workflows depend on your export pipeline.
